import java.util.*;
class Main {
 public static void main( String [] args ){
      accountAccess();
      System.out.print("Access granted");
 }
 public static void accountAccess(){
      Scanner input = new Scanner( System.in );
      System.out.print( "Enter your password:" );
      String password = input.next();
      if(!password.equals("dragon")){
            accountAccess();
      }
   }
 }